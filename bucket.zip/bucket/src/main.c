#include <kipr/wombat.h>
int Ccounter = 650;
int Ccounter1 = 650;
int Acounter = 2047;
int Acounter1 = 2047;
int up = 850;
int middle = 1700;
int down = 2040;
int open = 800;
int scoop = 1960;
int close = 1700;
int fadj = 11;
int RF = 0;
int LF = 1;
int RB = 2;
int LB = 3;
void FDrive(int Distance);
void BDrive(int Distance);
void LShift(int SDistance);
void RShift(int SDistance);
void TSquare1(int SQDistance);
void TSquare2(int point);
void TSquare2B(int point);
void BSquare(int speed);
int main()
{
    printf("Hello World\n");
    wait_for_light(5);
    shut_down_in(119);
    
    enable_servos();
    set_servo_position(0,middle);
    msleep(700);

    RShift(3500);
    motor(RF,0); motor(LF,0);
    motor(RB,0); motor(LB,0);
    msleep(500);

    cmpc(LF);
    while(gmpc(LF) < 4800-220) //180
    {
        motor(LF,100); motor(RF,-100);
        motor(LB,100); motor(RB,-100);
    }
    motor(RF,0); motor(LF,0);
    motor(RB,0); motor(LB,0);
    msleep(500);

    set_servo_position(0,scoop);
    set_servo_position(1,open);
    msleep(1000);

    TSquare1(3300); //forward to poms
    motor(RF,0); motor(LF,0);
    motor(RB,0); motor(LB,0);
    msleep(500);

    set_servo_position(0,down);
    msleep(1000);
    while (get_servo_position(1)< close)
    {
        set_servo_position(1, Ccounter);
        Ccounter = Ccounter + 10;
        msleep(20);
    }

    while (get_servo_position(0)> middle)
    {
        set_servo_position(0, Acounter);
        Acounter = Acounter - 10;
        msleep(20);
    }

    cmpc(LF);
    FDrive(500);
    motor(RF,0); motor(LF,0);
    motor(RB,0); motor(LB,0);
    msleep(500);

    cmpc(LF);
    while(gmpc(LF) < 2350-220) //turn to tray
    {
        motor(LF,100); motor(RF,-100);
        motor(LB,100); motor(RB,-100);
    }

    LShift(800);

    TSquare2(200);

    set_servo_position(0,middle);
    msleep(500);
    set_servo_position(1,open);

    //back square
    BSquare(50);

    FDrive(200);

    RShift(300);
    //drop bottle arm
    //wiggle
    //raise arm
    msleep(1500);
    TSquare2(200);

    cmpc(LF);
    while(gmpc(LF) > -2350+220) //turn to pom2
    {
        motor(LF,-100); motor(RF,100);
        motor(LB,-100); motor(RB,100);
    }
    //add full stop

    RShift(600);
    motor(LF,0); motor(RF,0);
    motor(LB,0); motor(RB,0);
    TSquare2(200);

    BDrive(-1800);
    motor(LF,0); motor(RF,0);
    motor(LB,0); motor(RB,0);
    set_servo_position(0,scoop);
    msleep(1000);
    set_servo_position(1,open);//
    msleep(1000);

    FDrive(400);

    cmpc(RF);
    while(gmpc(RF) < 500)
    {
        motor(LF,-100); motor(RF,100);
        motor(LB,-100); motor(RB,100);
    }
    FDrive(350);

    while(gmpc(RF) < 400)
    {
        motor(LF,-100); motor(RF,100);
        motor(LB,-100); motor(RB,100);
    }

    motor(LF,0); motor(RF,0);
    motor(LB,0); motor(RB,0);
    msleep(500);

    set_servo_position(0,down);
    msleep(500);
    while (get_servo_position(1)< close)
    {
        set_servo_position(1, Ccounter1);
        Ccounter1 = Ccounter1 + 10;
        msleep(20);
    }

    while (get_servo_position(0)> middle)
    {
        set_servo_position(0, Acounter1);
        Acounter1 = Acounter1 - 10;
        msleep(20);
    }
    msleep(500);

    cmpc(LF);
    while(gmpc(LF) < 2350-220) //turn to tray
    {
        motor(LF,100); motor(RF,-100);
        motor(LB,100); motor(RB,-100);
    }

    TSquare2(200);
    LShift(350);

    msleep(500);
    set_servo_position(1,open);

    while (digital(0) == 0 || digital(1) == 0)
    {
        if (digital(0) == 1 && digital(1) == 0)
        {
            motor(RF, 0); motor(RB,0);
            motor(LF,-50); motor(LB,-50);
        }
        else if (digital(0) == 0 && digital(1) == 1)
        {
            motor(RF,-50); motor(RB,-50);
            motor(LF,0); motor(LB,0);
        }
        else
        {
            motor(RF,-50); motor(RB,-50);
            motor(LF,-50); motor(LB,-50);
        }
    }
    motor(RF,0); motor(LF,0);
    motor(RB,0); motor(LB,0);
    msleep(500);

    RShift(1250);
    TSquare1(200);

    cmpc(LF);
    while(gmpc(LF) > -2350+220) //turn to pom2
    {
        motor(LF,-100); motor(RF,100);
        motor(LB,-100); motor(RB,100);
    }
    BDrive(700);
    TSquare2(200);
    RShift(700);
    disable_servos();
    return 0;
}
void FDrive(int Distance)
{
    cmpc(0);
    while(gmpc(0)<Distance)
    {
        motor(LF,100); motor(RF,100);
        motor(LB,100); motor(RB,100);
    }
}
void BDrive(int Distance)
{
    cmpc(0);
    while(gmpc(0)>Distance)
    {
        motor(LF,-100); motor(RF,-100);
        motor(LB,-100); motor(RB,-100);
    }
}
void LShift(int SDistance)
{
    cmpc(0);
    while (gmpc(0) < SDistance)
    {
        motor(RF,100); motor(LF,-100);
        motor(RB,-100); motor(LB,100);
    }

}
void RShift(int SDistance)
{
    cmpc(1);
    while (gmpc(1) < SDistance)
    {
        motor(RF,-100); motor(LF,100);
        motor(RB,100); motor(LB,-100);
    }

}
void TSquare1(int SQDistance)
{
    cmpc(0);
    while( gmpc(0)< SQDistance)
    {
        if (analog(0) >= 200 && analog(1) < 200)
        {
            motor(0,-100); motor(1,100);
            motor(2,-100); motor(3,100);
        }
        else if (analog(0) < 200 && analog(1) >= 200)
        {
            motor(0,100); motor(1,-100);
            motor(2,100); motor(3,-100);
        }
        else 
        {
            motor(0,100); motor(1,100);
            motor(2,100); motor(3,100);
        }
    }
    motor(0,0); motor(1,0);
    motor(2,0); motor(3,0);
    msleep(500);
}
void TSquare2(int point)
{
    while( analog(0) < point || analog(1) < point)
    {
        if (analog(0) >= point && analog(1) < point)
        {
            motor(0,-50); motor(1,50);
            motor(2,-50); motor(3,50);
        }
        else if (analog(0) < point && analog(1) >= point)
        {
            motor(0,50); motor(1,-50);
            motor(2,50); motor(3,-50);
        }
        else 
        {
            motor(0,75); motor(1,75);
            motor(2,75); motor(3,75);
        }
    }
    motor(0,0); motor(1,0);
    motor(2,0); motor(3,0);
    msleep(500);
}

void TSquare2B(int point)
{
    while( analog(0) < point || analog(1) < point)
    {
        if (analog(0) >= point && analog(1) < point)
        {
            motor(0,-50); motor(1,50);
            motor(2,-50); motor(3,50);
        }
        else if (analog(0) < point && analog(1) >= point)
        {
            motor(0,50); motor(1,-50);
            motor(2,50); motor(3,-50);
        }
        else 
        {
            motor(0,-50); motor(1,-50);
            motor(2,-50); motor(3,-50);
        }
    }
    motor(0,0); motor(1,0);
    motor(2,0); motor(3,0);
    msleep(500);
}
void BSquare(int speed)
{
    while (digital(0) == 0 || digital(1) == 0)
    {
        if (digital(0) == 1 && digital(1) == 0)
        {
            motor(RF, 0); motor(RB,0);
            motor(LF,-speed); motor(LB,-speed);
        }
        else if (digital(0) == 0 && digital(1) == 1)
        {
            motor(RF,-speed); motor(RB,-speed);
            motor(LF,0); motor(LB,0);
        }
        else
        {
            motor(RF,-speed); motor(RB,-speed);
            motor(LF,-speed); motor(LB,-speed);
        }
    }
    motor(LF,0); motor(RF,0);
    motor(LB,0); motor(RB,0);
    msleep(500);   
}