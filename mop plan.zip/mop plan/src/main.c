#include <kipr/wombat.h>
int fadj = 1;
int down = 0;
int mid = 600;
int up = 1200;
int eheight = 800;
int open = 2040;
int close = 1500;
int ACounter = 600;
int Ccounter = 2040;
void FDrive(int distance);
void LTurn(int degree);
void RTurn(int degree);
void STOP(int sleep);
void TSqre(int point);
void BTSqre(int point);
int main()
{
    wait_for_light(1);
    shut_down_in(119);
    printf("Hello World\n");
    enable_servos();

    set_servo_position(0, down);
    set_servo_position(1, open);
    msleep(1000);
    while (get_servo_position(0)< eheight)
    {
        set_servo_position(0, ACounter);
        ACounter = ACounter + 30;
        msleep(20);
    }

    FDrive(5200);
    STOP(500);

    while(get_servo_position(1)> close)
    {
        set_servo_position(1,Ccounter);
        Ccounter = Ccounter - 10;
        msleep(20);
    }
    STOP(500);

    BTSqre(200);
    LTurn(200);
    FDrive(800);
    msleep(500);
    LTurn(600);
    TSqre(200); //facing west

    FDrive(1500);
    LTurn(800);
    TSqre(200); 
    FDrive(400); // facing south
    STOP(500);
    RTurn(600);
    TSqre(200);

    cmpc(3);
    while(gmpc(3)<1200)
    {
        motor(0,0);
        motor(3,100);
    }
    TSqre(200);
    STOP(500);
    cmpc(3);
    while(gmpc(3)<300)
    {
        motor(0,0);
        motor(3,100);
    }
    set_servo_position(0,down);
    msleep(500);
    set_servo_position(1,open);
    return 0;
}
void STOP(int sleep)
{
    motor(0,0);
    motor(3,0);
    msleep(sleep);
}
void FDrive (int distance)
{
    cmpc(0);
    while(gmpc(0)<distance)
    {
        motor(0,100);
        motor(3,100-fadj);
    }
}
void RTurn(int degree)
{
    cmpc(0);
    while(gmpc(0)<degree)
    {
        motor(0,100);
        motor(3,-100);
    }
}
void LTurn(int degree)
{
    cmpc(3);
    while(gmpc(3)<degree)
    {
        motor(0,-100);
        motor(3,100);
    }
}
void TSqre(int point)
{
    while( analog(0) < point || analog(5) < point)
    {
        if (analog(0) >= point && analog(5) < point)
        {
            motor(0,-50); 
            motor(3,50);
        }
        else if (analog(0) < point && analog(5) >= point)
        {
            motor(0,50); 
            motor(3,-50);
        }
        else 
        {
            motor(0,75);
            motor(3,75);
        }
    }
    motor(0,0); 
    motor(3,0);
    msleep(500);
}
void BTSqre(int point)
{
    while( analog(0) < point || analog(5) < point)
    {
        if (analog(0) >= point && analog(5) < point)
        {
            motor(0,50); 
            motor(3,-50);
        }
        else if (analog(0) < point && analog(5) >= point)
        {
            motor(0,-50); 
            motor(3,50);
        }
        else 
        {
            motor(0,-75); 
            motor(3,-75);
        }
    }
    motor(0,0); motor(1,0);
    motor(2,0); motor(3,0);
    msleep(500);
}
